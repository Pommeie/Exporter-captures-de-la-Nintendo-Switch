#importations
import ctypes,os,shutil
from tkinter import * #importation du module permetant de créer l'application

#definition des variables
user32 = ctypes.windll.user32
largeur , hauteur = user32.GetSystemMetrics(0) , user32.GetSystemMetrics(1)
nom_des_mois = ["01 Janvier","02 Février"," 03 Mars","04 Avril","05 Mai","06 Juin","07 Juillet","08 Août"," 09 Septembre","10 Octobre","11 Novembre","12 Décembre"]
nombre_de_screens_total = 0
couleur_de_fond = "#202020"
couleur_des_boutons = "#323232"
couleur_du_texte = "#FFFFFF"
exportation = False
carte = False
source = "F:/Nintendo/Album"

#definition des fonctions
def dossier(adresse):
    if os.path.exists(adresse) == False:
        parties = adresse.split("/")
        adresse = ""
        for partie in parties[:-1]:
            adresse += partie
            adresse += "/"
        if os.path.exists(adresse):
            print(f'''Création du nouveau dossier "{parties[-1]}" à l'adresse "{adresse}"''')
            print(adresse + "/" + parties[-1])
            os.mkdir(adresse + "/" + parties[-1])
    else:
        print("Le dossier existe déjà")

def dossier2(adresse):
    if os.path.exists(adresse) == False:
        os.mkdir(adresse)
        print(f"Création du dossier {adresse}")

def export():
    global exportation
    if carte == True:
        if exportation == False:
            exportation = True
            texte = Label(question, text="Entrez la destination des fichiers ci dessous:",font=("Arial", 12), bg=couleur_de_fond, fg=couleur_du_texte)
            texte.pack(side=LEFT)
            #destination = "C:/Users/pomme/Pictures/Screens Switch"
            destination.pack(side=RIGHT)
            selection = Button(question,text="Destination par défaut", font=("Arial", 10), bg=couleur_des_boutons, fg="#9999FF", command=remplissage,bd=NO,borderwidth=0)
            selection.pack(side=RIGHT,pady=(int(hauteur*0.01)))
            #affichage de la loupe
            canva.pack(side=LEFT)
            entree.pack()

        else:
        
            if destination.get() == "" or os.path.exists(destination.get()) == False :
                texte = Label(window, text=f"L'entrée n'est pas valide",font=("Arial", 8), bg=couleur_de_fond, fg=couleur_du_texte)
                texte.pack()
                dossier(str(destination.get()))
            for annee in os.listdir(f"{source}"):
                if annee != "Extra":
                    dossier(f"{destination.get()}/{annee}")
                    print(f"ouvertur de {destination.get()}/{annee}")
                    for mois in os.listdir(f"{source}/{annee}"):
                        print(f"ouvertur de {destination.get()}/{annee}/{nom_des_mois[int(mois)-1]}")
                        dossier(f"{destination.get()}/{annee}/{nom_des_mois[int(mois)-1]}")
                        for jour in os.listdir(f"{source}/{annee}/{mois}"):
                                print(f"ouverture de {destination.get()}/{annee}/{mois}")
                                for element in os.listdir(f"{source}/{annee}/{mois}/{jour}"):
                                    
                                    texte = Label(window, text=f"Le fichier {source}/{annee}/{mois}/{jour}/{element} a été déplacé vers {destination.get()}/{annee}/{nom_des_mois[int(mois)-1]}",font=("Arial", 8), bg=couleur_de_fond, fg=couleur_du_texte)
                                    texte.pack()
                                    shutil.copy2(f"{source}/{annee}/{mois}/{jour}/{element}", f"{destination.get()}/{annee}/{nom_des_mois[int(mois)-1]}")

def remplissage():
    destination.delete(0,200000)
    destination.insert(0,f"C:/Users/{os.getlogin()}/Pictures/Captures Nintendo Switch")

#création de la fenêtre
window = Tk() #création de l'instance de l'application
window.title("Export pictures from Nintendo Switch") #titre de l'application
window.iconbitmap("icon-album.ico") #ajout d'une icône à l'applicaion
window.config(background=couleur_de_fond) #ajout d'un fond à l'application

#réglages de la taille
window.geometry(f"{int(largeur*0.5)}x{(int(hauteur*0.5))}") #taille par défaut
window.minsize(int(largeur*0.2),(int(hauteur*0.2))) #taille minimale
#window.maxsize(int(largeur*0.5),(int(hauteur*0.5))) #taille minimale

#affichage du texte et des boutons

texte = Label(window, text="Retrouvez ici tous ce dont vous aurez besoin en ce qui concerne vos captures de jeu:",font=("Arial", 12), bg=couleur_de_fond, fg=couleur_du_texte)
texte.pack()

if os.path.exists(f"{source}"):
    carte = True
    for annee in os.listdir(f"{source}"):
        if annee != "Extra":
            for mois in os.listdir(f"{source}/{annee}"):
                for jour in os.listdir(f"{source}/{annee}/{mois}"):
                    nombre_de_screens = len(os.listdir(f"{source}/{annee}/{mois}/{jour}"))
                    nombre_de_screens_total += nombre_de_screens 

    texte = Label(window, text=f"Fichiers trouvés: {nombre_de_screens_total}",font=("Arial", 15), bg=couleur_de_fond, fg=couleur_du_texte)
    texte.pack()

else:
    texte = Label(window, text="La carte n'est pas détectée!",font=("Arial", 15), bg=couleur_de_fond, fg='red')
    texte.pack()

#frame question
question = Frame(window, bg=couleur_de_fond, bd=1)
question.pack()
entree = Frame(window, bg=couleur_de_fond, bd=1)
h , l = 32 , 32
image_loupe = PhotoImage(file="loupe.png").zoom(10).subsample(l,l)
canva = Canvas(entree , width=l , height=h , bg= couleur_de_fond , bd=NO , highlightthickness=0)
canva.create_image(l/2,h/2,image=image_loupe)
destination = Entry(entree, font=("Arial", 15), bg=couleur_des_boutons, fg=couleur_du_texte,bd=NO)
selection = Button(question,text="Exporter les images", font=("Arial", 15), bg=couleur_des_boutons, fg=couleur_du_texte, command=export , bd=NO)
selection.pack(pady=(int(hauteur*0.01)))
credits = Label(window, text="Rochette Dimitri 27/08/2023",font=("Arial", 7), bg=couleur_de_fond, fg=couleur_du_texte)
credits.pack(side=BOTTOM)

window.mainloop() #démarrage de l'application