#importations
import ctypes , shutil , win32api , os , psutil , Images
from tkinter import * #importation du module permetant de créer l'application

#definition des variables
user32 = ctypes.windll.user32
largeur , hauteur = user32.GetSystemMetrics(0) , user32.GetSystemMetrics(1)
nom_des_mois = ["01 Janvier","02 Février"," 03 Mars","04 Avril","05 Mai","06 Juin","07 Juillet","08 Août"," 09 Septembre","10 Octobre","11 Novembre","12 Décembre"]
repertoire = []
nombre_de_screens_total = 0
couleur_de_fond = "#202020"
couleur_des_boutons = "#323232"
couleur_du_texte = "#FFFFFF"
exportation = False
carte = False
element_actuel = 0

ppl = lettre , taille = psutil.disk_partitions()[0].device , (psutil.disk_usage(psutil.disk_partitions()[0].mountpoint).total) / (1024 ** 3)
for partition in psutil.disk_partitions():
    usage = psutil.disk_usage(partition.mountpoint)
    if usage.total / (1024 ** 3) < taille:
        ppl = lettre , taille = partition.device , usage.total / (1024 ** 3)
source = f"{lettre[0]}:/"
lecteurs = str(win32api.GetLogicalDriveStrings())
for i in range(lecteurs.count(":")):
    if os.path.exists(f"{lecteurs[i*4]}:/Nintendo/Album"):
        source =  f"{lecteurs[i*4]}:/Nintendo/Album"

#definition des fonctions
def dossier(adresse):
    if os.path.exists(adresse) == False:
        parties = adresse.split("/")
        adresse = ""
        for partie in parties[:-1]:
            adresse += partie
            adresse += "/"
        if os.path.exists(adresse):
            print(f'''Création du nouveau dossier "{parties[-1]}" à l'adresse "{adresse}"''')
            print(adresse + "/" + parties[-1])
            os.mkdir(adresse + "/" + parties[-1])
    else:
        print("Le dossier existe déjà")

def dossier2(adresse):
    if os.path.exists(adresse) == False:
        os.mkdir(adresse)
        print(f"Création du dossier {adresse}")
    else:
        print(f"Ouvertur de {destination.get()}/{annee}")

def export():
    global exportation
    if carte == True:
        if exportation == False:
            exportation = True
            texte = Label(question, text="Entrez la source et la destination des fichiers ci dessous:",font=("Arial", 12), bg=couleur_de_fond, fg=couleur_du_texte)
            texte.pack(side=LEFT)
            #destination = "C:/Users/pomme/Pictures/Screens Switch"
            entree_src.pack(side=LEFT)
            destination.pack(side=RIGHT)
            selection = Button(question,text="Source par défaut", font=("Arial", 10), bg=couleur_des_boutons, fg="#9999FF", command=remplissage_src,bd=NO,borderwidth=0)
            selection.pack(side=LEFT,padx=(int(hauteur*0.01)))
            selection = Button(question,text="Destination par défaut", font=("Arial", 10), bg=couleur_des_boutons, fg="#9999FF", command=remplissage_dst,bd=NO,borderwidth=0)
            selection.pack(side=RIGHT)
            #affichage de la loupe
            canva.pack(side=LEFT)
            entree.pack()

        else:
        
            if destination.get() == "" or os.path.exists(destination.get()) == False :
                texte = Label(window, text=f"L'entrée n'est pas valide",font=("Arial", 8), bg=couleur_de_fond, fg=couleur_du_texte)
                texte.pack()
                dossier(str(destination.get()))
            for annee in os.listdir(f"{source}"):
                if annee != "Extra":
                    dossier(f"{destination.get()}/{annee}")
                    for mois in os.listdir(f"{source}/{annee}"):
                        dossier(f"{destination.get()}/{annee}/{nom_des_mois[int(mois)-1]}")
                        for jour in os.listdir(f"{source}/{annee}/{mois}"):
                                for element in os.listdir(f"{source}/{annee}/{mois}/{jour}"):
                                    print(f"Le fichier {source}/{annee}/{mois}/{jour}/{element} a été déplacé vers {destination.get()}/{annee}/{nom_des_mois[int(mois)-1]}")
                                    shutil.copy2(f"{source}/{annee}/{mois}/{jour}/{element}", f"{destination.get()}/{annee}/{nom_des_mois[int(mois)-1]}")

def remplissage_src():
    entree_src.delete(0,200000)
    entree_src.insert(0,f"{source}")

def remplissage_dst():
    destination.delete(0,200000)
    destination.insert(0,f"C:/Users/{os.getlogin()}/Pictures/Captures Nintendo Switch")

#création de la fenêtre
window = Tk() #création de l'instance de l'application
window.title("Exporter les captures de la Nintendo Switch") #titre de l'application
window.iconbitmap("Images/icon-album.ico") #ajout d'une icône à l'applicaion
window.config(background=couleur_de_fond) #ajout d'un fond à l'application

#réglages de la taille
window.geometry(f"{int(largeur*0.5)}x{(int(hauteur*0.5))}") #taille par défaut
window.minsize(int(largeur*0.4),(int(hauteur*0.3))) #taille minimale
#window.maxsize(int(largeur*0.5),(int(hauteur*0.5))) #taille minimale

#affichage du texte et des boutons

texte = Label(window, text="Vous pouvez sélectionner la source et la destination du transfert des captures",font=("Arial", 12), bg=couleur_de_fond, fg=couleur_du_texte)
texte.pack()

if os.path.exists(f"{source}"):
    carte = True
    for annee in os.listdir(f"{source}"):
        if annee != "Extra":
            for mois in os.listdir(f"{source}/{annee}"):
                for jour in os.listdir(f"{source}/{annee}/{mois}"):
                    for element in os.listdir(f"{source}/{annee}/{mois}/{jour}"):
                        nombre_de_screens_total += 1
                        repertoire.append(f"{source}/{annee}/{mois}/{jour}/{element}")

    texte = Label(window, text=f"Fichiers trouvés: {nombre_de_screens_total}",font=("Arial", 15), bg=couleur_de_fond, fg=couleur_du_texte)
    texte.pack()

else:
    texte = Label(window, text="La carte n'est pas détectée!",font=("Arial", 15), bg=couleur_de_fond, fg='red')
    texte.pack()

#frame question
question = Frame(window, bg=couleur_de_fond, bd=1)
question.pack()
entree = Frame(window, bg=couleur_de_fond, bd=1)
titres = Frame(entree, bg=couleur_des_boutons, bd=NO)
titres.pack()
sortie = Frame(window, bg=couleur_de_fond, bd=1)
sortie.pack()
texte_src = Label(titres, text="Adresse source                      ",font=("Arial", 15), bg=couleur_de_fond, fg=couleur_du_texte)
texte_src.pack(side=LEFT,anchor="w")
texte_dst = Label(titres, text="                      Adresse de destination",font=("Arial", 15), bg=couleur_de_fond, fg=couleur_du_texte)
texte_dst.pack(side=RIGHT,anchor="e")
h , l = 32 , 32
image_loupe = PhotoImage(file="Images/loupe.png").zoom(10).subsample(l,l)
canva = Canvas(entree , width=l , height=h , bg= couleur_de_fond , bd=NO , highlightthickness=0)
canva.create_image(l/2,h/2,image=image_loupe)
destination = Entry(entree, font=("Arial", 15), bg=couleur_des_boutons, fg=couleur_du_texte,bd=NO)
entree_src = Entry(entree, font=("Arial", 15), bg=couleur_des_boutons, fg=couleur_du_texte,bd=NO)
selection = Button(question,text="Exporter les captures", font=("Arial", 15), bg=couleur_des_boutons, fg=couleur_du_texte, command=export , bd=NO)
selection.pack(pady=(int(hauteur*0.01)))

credits = Label(window, text="Rochette Dimitri 27/08/2023",font=("Arial", 7), bg=couleur_de_fond, fg=couleur_du_texte)
credits.pack(side=BOTTOM)

window.mainloop() #démarrage de l'application